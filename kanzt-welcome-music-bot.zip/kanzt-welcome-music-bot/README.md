# Kanzt Welcome + Music Bot

JavaScript / discord.js v14. Includes:
- Welcome message using your custom GIF URL
- `/play` with YouTube links/search, Spotify track/playlist links (resolved through configured playable providers), and SoundCloud links/search where supported
- `/pause`, `/resume`, `/skip`, `/stop`, `/queue`, `/nowplaying`, `/volume`, `/leave`
- Buttons for Pause / Resume / Skip / Stop on music responses
- Lavalink v4 + YouTube source plugin + LavaSrc
- Docker Compose for running the bot and Lavalink together

## Important about music sources
Spotify is not used as a raw audio stream by this bot. LavaSrc reads Spotify track/playlist metadata and attempts to resolve playable audio through the configured provider list (YouTube Music, YouTube, then SoundCloud). Some tracks or links may fail depending on provider availability, region, access restrictions, and service changes. Only use sources and audio you are authorized to play. This project does not bypass paid access or DRM.

## 1. Discord Developer Portal
1. Create an application at https://discord.com/developers/applications.
2. Under **Bot**, create/copy the bot token.
3. Enable **Server Members Intent** for welcome messages.
4. Invite the bot through **OAuth2 → URL Generator** with scope `bot` and `applications.commands`.
5. Bot permissions: View Channels, Send Messages, Embed Links, Attach Files, Connect, Speak.
6. Copy the Application ID into `CLIENT_ID`.
7. Copy the welcome channel ID into `WELCOME_CHANNEL_ID` (enable Developer Mode in Discord settings first).

## 2. Configure
Copy `.env.example` to `.env`, then fill in:
- `DISCORD_TOKEN`
- `CLIENT_ID`
- `WELCOME_CHANNEL_ID`
- `LAVALINK_PASSWORD` (set a long random password)
- Optional `GUILD_ID` to register slash commands to one server immediately. Leave blank for global registration.

Keep `.env` secret. Never commit it to a public repository.

## 3. Run with Docker Compose (recommended)
Requires a host with Docker Engine + Docker Compose and persistent containers.

```bash
docker compose up -d --build
docker compose logs -f
```

Register slash commands (run once after setting `.env`):

```bash
docker compose run --rm bot npm run deploy-commands
```

If you use a test server, fill `GUILD_ID` to make commands appear faster. If it is blank, global command propagation may take time.

To restart after changing config:
```bash
docker compose up -d --build
```

## 4. Run the bot outside Docker
You still need a separate, reachable Lavalink v4 server. Set `LAVALINK_HOST`, `LAVALINK_PORT`, and `LAVALINK_PASSWORD` in `.env`, then:

```bash
npm install
npm run deploy-commands
npm start
```

For a host that runs the bot and Lavalink as separate services, set `LAVALINK_HOST` to the private hostname of the Lavalink service, not `localhost`.

## 5. Slash commands
- `/play query:<title or URL>`
- `/pause`
- `/resume`
- `/skip`
- `/stop`
- `/queue`
- `/nowplaying`
- `/volume level:<1-100>`
- `/leave`

Users must be in a voice channel to start or control playback, and the bot needs Connect/Speak permissions.

## 6. 24/7 deployment
Deploy both services:
- `bot`: Node.js process
- `lavalink`: Java audio node

Use an always-on VPS or container host that supports Docker Compose and outbound WebSocket connections. Some free platforms sleep or prohibit long-running voice/audio processes. Do not expose the Lavalink port publicly; the compose file keeps it internal.

## Troubleshooting
- **Bot online, no music:** check Lavalink logs and verify host/password match.
- **Commands missing:** run `npm run deploy-commands`; check CLIENT_ID, bot invite scope, and GUILD_ID.
- **Bot cannot join/speak:** grant Connect and Speak permissions in the voice channel.
- **Spotify URL has no playable track:** some Spotify tracks can only provide metadata; try another source or a different query.
- **YouTube/SoundCloud fails:** provider availability can change. Review Lavalink logs and current plugin docs.
- **Welcome GIF missing:** check that WELCOME_GIF_URL is publicly accessible and ends in `.gif`.

Official docs:
- Lavalink: https://lavalink.dev/
- Lavalink client: https://lc4.gitbook.io/lavalink-client/
- LavaSrc: https://github.com/topi314/LavaSrc
- YouTube source plugin: https://github.com/lavalink-devs/youtube-source
